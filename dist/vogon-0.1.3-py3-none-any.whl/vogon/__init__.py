# __init__.py
from .vogon import create_settings_template, ensure_settings
from .config import set_setting_filepath, load_config_path, save_config_path